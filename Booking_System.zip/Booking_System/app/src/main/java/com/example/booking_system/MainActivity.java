package com.example.booking_system;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    // Define the buttons for each seat
    private Button seatF, seatG, seatC, seatD, seatJ, seatM, seatO, seatP, seatQ;
    private boolean[] seatStatus = new boolean[9]; // To track seat status

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the buttons for each seat
        seatF = findViewById(R.id.seatF);
        seatG = findViewById(R.id.seatG);
        seatC = findViewById(R.id.seatC);
        seatD = findViewById(R.id.seatD);
        seatJ = findViewById(R.id.seatJ);
        seatM = findViewById(R.id.seatM);
        seatO = findViewById(R.id.seatO);
        seatP = findViewById(R.id.seatP);
        seatQ = findViewById(R.id.seatQ);

        // Initialize seat status to all seats being available
        for (int i = 0; i < seatStatus.length; i++) {
            seatStatus[i] = true;
        }

        // Set click listeners for the seat buttons
        seatF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleSeatSelection(seatF, 0);
            }
        });

        seatG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleSeatSelection(seatG, 1);
            }
        });

        seatC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleSeatSelection(seatC, 2);
            }
        });

        seatD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleSeatSelection(seatD, 3);
            }
        });

        seatJ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleSeatSelection(seatJ, 4);
            }
        });

        seatM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleSeatSelection(seatM, 5);
            }
        });

        seatO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleSeatSelection(seatO, 6);
            }
        });

        seatP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleSeatSelection(seatP, 7);
            }
        });

        seatQ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleSeatSelection(seatQ, 8);
            }
        });

        // Handle the "Confirm Selection" button click
        Button confirmButton = findViewById(R.id.confirmbutton);
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmSelection();
            }
        });

        // Handle the "Cancel Selection" button click
        Button cancelButton = findViewById(R.id.cancelbutton);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cancelSelection();
            }
        });
    }

    // Method to select or cancel a seat and show a toast message
    private void toggleSeatSelection(Button seatButton, int seatIndex) {
        if (seatStatus[seatIndex]) {
            // Seat is available, select it
            seatStatus[seatIndex] = false;
            seatButton.setBackgroundColor(Color.RED);
            Toast.makeText(this, "Seat is selected", Toast.LENGTH_SHORT).show();
        } else {
            // Seat is already booked, cancel the selection
            seatStatus[seatIndex] = true;
            seatButton.setBackgroundColor(Color.GREEN); // Change color to available (green)
            Toast.makeText(this, "Seat selection canceled", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to confirm seat selection and change seat colors to red
    private void confirmSelection() {
        for (int i = 0; i < seatStatus.length; i++) {
            if (!seatStatus[i]) {
                // Seat is selected (already booked), change its color to red
                switch (i) {
                    case 0:
                        seatF.setBackgroundColor(Color.RED);
                        break;
                    case 1:
                        seatG.setBackgroundColor(Color.RED);
                        break;
                    case 2:
                        seatC.setBackgroundColor(Color.RED);
                        break;
                    case 3:
                        seatD.setBackgroundColor(Color.RED);
                        break;
                    case 4:
                        seatJ.setBackgroundColor(Color.RED);
                        break;
                    case 5:
                        seatM.setBackgroundColor(Color.RED);
                        break;
                    case 6:
                        seatO.setBackgroundColor(Color.RED);
                        break;
                    case 7:
                        seatP.setBackgroundColor(Color.RED);
                        break;
                    case 8:
                        seatQ.setBackgroundColor(Color.RED);
                        break;
                }
            }
        }
        Toast.makeText(this, "Seats are booked successfully", Toast.LENGTH_SHORT).show();
    }

    // Method to cancel seat selection and change seat colors to green
    private void cancelSelection() {
        for (int i = 0; i < seatStatus.length; i++) {
            if (!seatStatus[i]) {
                // Seat is selected, change its color to green (available)
                seatStatus[i] = true;
                switch (i) {
                    case 0:
                        seatF.setBackgroundColor(Color.GREEN);
                        break;
                    case 1:
                        seatG.setBackgroundColor(Color.GREEN);
                        break;
                    case 2:
                        seatC.setBackgroundColor(Color.GREEN);
                        break;
                    case 3:
                        seatD.setBackgroundColor(Color.GREEN);
                        break;
                    case 4:
                        seatJ.setBackgroundColor(Color.GREEN);
                        break;
                    case 5:
                        seatM.setBackgroundColor(Color.GREEN);
                        break;
                    case 6:
                        seatO.setBackgroundColor(Color.GREEN);
                        break;
                    case 7:
                        seatP.setBackgroundColor(Color.GREEN);
                        break;
                    case 8:
                        seatQ.setBackgroundColor(Color.GREEN);
                        break;
                }
            }
        }
        Toast.makeText(this, "Seat selection canceled", Toast.LENGTH_SHORT).show();
    }
}
